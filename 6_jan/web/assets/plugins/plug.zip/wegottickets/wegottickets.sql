-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 27, 2013 at 03:19 PM
-- Server version: 5.6.12
-- PHP Version: 5.5.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `wegottickets`
--
CREATE DATABASE IF NOT EXISTS `wegottickets` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `wegottickets`;

-- --------------------------------------------------------

--
-- Table structure for table `masterusers`
--

CREATE TABLE IF NOT EXISTS `masterusers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `is_actived` int(1) NOT NULL DEFAULT '0' COMMENT '1:Enabled, 0:Disabled',
  `is_deleted` int(1) NOT NULL DEFAULT '0' COMMENT '1:Deleted, 0:Not Deleted',
  `user_type` int(1) NOT NULL DEFAULT '5' COMMENT '1:Admin, 2:Masteruser, 3:Superuser, 4:User, 5:Customer',
  `created_by` int(10) NOT NULL DEFAULT '0',
  `last_login` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Dumping data for table `masterusers`
--

INSERT INTO `masterusers` (`id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address`, `is_actived`, `is_deleted`, `user_type`, `created_by`, `last_login`, `created_at`) VALUES
(8, 'Amit', 'Meena', 'amit.m@gmail.com', '', '9876987698', 'Raisen', 0, 0, 1, 0, '', '2013-11-18 06:57:36'),
(9, 'Rajkumar', 'Rajpoot', 'rajkumar@gmail.com', '', '9876987698', 'Bhopal', 0, 0, 1, 0, '', '2013-11-18 06:58:24'),
(10, 'Vshu dev', 'Choudhry', 'vasudev.c@gmail.com', '', '9876987698', 'Khandwa', 0, 0, 1, 0, '', '2013-11-18 06:59:50'),
(11, 'Mlkhan ', 'Parmar', 'malkhan.p@cisinlabs.com', '', '9876987698', 'INdore', 0, 0, 1, 0, '', '2013-11-18 07:02:00'),
(12, 'Jaswant', 'jatav', 'jaswant.s@cisinlabs.com', 'e10adc3949ba59abbe56e057f20f883e', '9893368545', 'indore', 0, 0, 0, 0, '27-11-2013 01:46:29 pm', '2013-11-18 08:51:29'),
(13, 'Admin', 'manager', 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '8976897698', 'India', 0, 0, 1, 0, '22-11-2013 07:51:22 am', '2013-11-18 09:16:29'),
(14, 'mayank', 'awasthi', 'mayank.a@cisinlabs.com', 'e10adc3949ba59abbe56e057f20f883e', '9787878787', 'indore', 0, 0, 2, 0, '21-11-2013 08:59:22 am', '2013-11-18 10:40:56'),
(15, 'Rajendra', 'Khabia', 'rajendra.k@cisinlabs.com', '', '9876987698', 'Bhopal', 0, 0, 3, 0, '', '2013-11-19 01:36:11'),
(16, 'Anamika', 'Verma', 'anamika.v@gmail.com', '', '8765987698', 'Indore', 0, 0, 2, 0, '', '2013-11-19 01:36:45'),
(17, 'Gawrav', 'Chawda', 'gawraw.c@yahoo.com', '', '8765987608', 'Ujjain', 0, 0, 4, 0, '', '2013-11-19 01:37:31'),
(18, 'Animesh', 'sharma', 'animesh.s@cisinlab.com', '', '8709823470', 'Raisen', 0, 0, 4, 0, '', '2013-11-19 01:38:07'),
(19, 'Rajkapoor', 'singh', 'rajkapoor.c@cisinlab.som', '', '2390847502', 'Bhopal', 0, 0, 4, 0, '', '2013-11-19 01:39:47'),
(20, 'edfhg', 'dfgh', 'dfghdfg@trgg.dgf', '', '4653456345', 'dfhgdfgh', 0, 0, 1, 0, '', '2013-11-20 00:30:05');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
