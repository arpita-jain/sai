$(function() {
  $("table").tablesorter({
      debug: true,
      widgets: ["zebra", "filter"],
  });
});
