<?php

/**
 * Created by JetBrains PhpStorm.
 * User: nick
 * Date: 20/11/13
 * Time: 21:08
 * To change this template use File | Settings | File Templates.
 */
//WeGotTickets will create an autoload these requires in the next release
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Client/Event.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Client/LineItem.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Client/PriceAndStock.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Client/Rest.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Client/TicketType.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Client/Venue.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Client/Kiosk.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Wrapper/Wrapper.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Wrapper/DummyWrapper.php';

use InternetTickets\WeGotTickets\Api\v1\Client;

$kiosk = Client\Kiosk::create();

$result['success'] = "";
$result['error'] = "";
//Collect all Kiosk stock information from the WeGotTickets server
try {
    $kioskData = $kiosk->fetchAllData();
} catch (Exception $ex) {
    //Note Exceptions are still being defined
    $result['error'] = $ex->getMessage();
}
?>
<pre>
<?php 
print_r($kioskData);
?>
</pre>
 
<?php

$ticketsData = array();
foreach ($kioskData['tickettypes'] as $ticket) {
    $tickets=array();
    $tickets['type'] = $ticket->type();
    $tickets['currency'] = $ticket->currency();
    $tickets['price'] = $ticket->price();
    $tickets['onsale'] = $ticket->onsale();
    $tickets['stockUnsold'] = $ticket->stockUnsold();
    $tickets['stockAvailable'] = $ticket->stockAvailable();
    $ticketsData[]=$tickets;
}

echo json_encode($ticketsData);
