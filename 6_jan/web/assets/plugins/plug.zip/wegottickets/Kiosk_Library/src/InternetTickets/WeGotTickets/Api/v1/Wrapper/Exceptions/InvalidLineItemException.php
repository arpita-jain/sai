<?php
namespace InternetTickets\WeGotTickets\Api\v1\Wrapper\Exceptions;

class InvalidLineItemException extends \InvalidArgumentException {}