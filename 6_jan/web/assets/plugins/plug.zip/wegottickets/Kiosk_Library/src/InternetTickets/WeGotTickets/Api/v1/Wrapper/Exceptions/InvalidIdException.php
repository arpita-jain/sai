<?php

namespace InternetTickets\WeGotTickets\Api\v1\Wrapper\Exceptions;


class InvalidIdException extends \InvalidArgumentException {}