<?php

/**
 * Created by JetBrains PhpStorm.
 * User: nick
 * Date: 20/11/13
 * Time: 21:08
 * To change this template use File | Settings | File Templates.
 */
//WeGotTickets will create an autoload these requires in the next release
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Client/Event.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Client/LineItem.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Client/PriceAndStock.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Client/Rest.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Client/TicketType.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Client/Venue.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Client/Kiosk.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Wrapper/Wrapper.php';
require_once 'src/InternetTickets/WeGotTickets/Api/v1/Wrapper/DummyWrapper.php';

use InternetTickets\WeGotTickets\Api\v1\Client;

$kiosk = Client\Kiosk::create();

//Collect all Kiosk stock information from the WeGotTickets server
try {
    $kioskData = $kiosk->fetchAllData();
} catch (Exception $ex) {
    //Note Exceptions are still being defined
    echo "<br>fetchAllData Failed" . $ex->getMessage();
}

/* Note we have found a bug that the demo data swaps the date for
  telephone number and website
  and Country and postcode
  We will fix this in the next release of the demo library
 */
echo "\n\n***********Venue Data*****************\n";
echo "<br>";
foreach ($kioskData['venues'] as $venue) {
    echo $venue->name();
    echo "<br>\n" . implode("<br>\n", $venue->address());
    echo "<br>\n" . $venue->town();
    echo "<br>\n" . $venue->postcode();
    echo "<br>\n***************\n";
}
echo "<br>";
echo "\n\n***********Event Data*****************\n";
echo "<br>";
foreach ($kioskData['events'] as $event) {
    echo $event->title();
    echo "<br>\n" . $event->date();
    echo "<br>\n" . $event->status();
    echo "<br>\n" . $event->description();
    echo "<br>\n" . $event->time();
    echo "<br>\n" . $event->ageLimit();
    echo "<br><br><br><br><br>\n***************\n";
}
echo "<br>";
echo "\n\n***********tickettypes Data*****************\n";
echo "<br>";
foreach ($kioskData['tickettypes'] as $ticket) {
    echo $ticket->type();
    echo "<br>\n" . $ticket->currency();
    echo "<br>\n" . $ticket->price();
    echo "<br>\n" . $ticket->onsale();
    echo "<br>\n" . $ticket->stockUnsold();
    echo "<br>\n" . $ticket->stockAvailable();
    echo "<br><br><br><br><br>\n***************\n";
}


echo "<br>";
echo "\n\n***********ticketStockAndPrice Data*****************\n";
echo "<br>";
//Price (in pence) and Stock using ticketType id
$kioskStockAndPriceData = $kiosk->fetchPriceAndStockFor(Array(34971, 34969));
echo "\n\n" . var_dump($kioskStockAndPriceData);

//Unique identifier created by the Kiosk software to track reservations
try {
    $reservationId = uniqid();
} catch (Exception $ex) {
    //Exceptions are still in development
    echo "<br>fetchPriceAndStockFor Failed" . $ex->getMessage();
}
 

//Reserve tickets (In basket)
//Repeated reserve tickets with the same ticketTypeId and Price but different quantity will update the quantity.
try {
    $kiosk->reserveTickets($reservationId, array(
        array(
            'ticketTypeId' => 34971,
            'price' => 2100,
            'quantity' => 4,
        )
    ));
} catch (Exception $ex) {
    //Exceptions are still in development
    echo "<br>reserveTickets Failed" . $ex->getMessage();
}

//Release all tickets reserved under a reservation id
try {
    $kiosk->releaseTickets($reservationId);
} catch (Exception $ex) {
    //Exceptions are still in development
    echo "<br>releaseTickets Failed" . $ex->getMessage();
}


//Marks stock as sold
try {
    $kiosk->transactTickets($reservationId, array(
        array(
            'ticketTypeId' => 34971,
            'price' => 2100,
            'quantity' => 4,
        )
    ));
} catch (Exception $ex) {
    //Exceptions are still in development
    echo "<br>transactTickets Failed" . $ex->getMessage();
}

//Return Stock (Note not all stock must be returned)
try {
    $kiosk->refundTickets($reservationId, array(
        array(
            'ticketTypeId' => 34971,
            'price' => 2100,
            'quantity' => 4,
        )
    ));
} catch (Exception $ex) {
    //Exceptions are still in development
    echo "<br>refund Failed" . $ex->getMessage(), "<br>";
}

