<?php
require(APPPATH.'libraries/REST_Controller.php');

class Example_api extends REST_Controller {

    function user_get()
    {
		// respond with information about a user
    }
    
    function users_get()
    {
		// respond with information about several users
    }
}
?>