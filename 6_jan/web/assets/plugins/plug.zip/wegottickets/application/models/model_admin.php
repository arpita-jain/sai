<?php

/*
 * Class Description
 * Project Name: wegottickets
 * Class name : Model_admin
 * File name Model_admin.php
 */

class Model_admin extends CI_Model {

    function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->library('session');
        $this->load->library('email');
    }

    public function logged_in() {

        log_message('info', 'Model_users logged_in method called successfully');
        $this->db->select('*');
        $this->db->from("masterusers");
        $this->db->where('email', $this->input->post('username'));
        $this->db->where('password', md5($this->input->post('password')));
//        $this->db->where('user_type', 1);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return $query->row_array();
        }
    }

    public function getStatistics() {
        //Get Admins count
        $this->db->where('user_type', 1);
        $this->db->from('masterusers');
        $admins = $this->db->count_all_results();

        //Get Masters count
        $this->db->where('user_type', 2);
        $this->db->from('masterusers');
        $masters = $this->db->count_all_results();

        //Get Supervisors count
        $this->db->where('user_type', 3);
        $this->db->from('masterusers');
        $supervisors = $this->db->count_all_results();

        //Get Users count
        $this->db->where('user_type', 4);
        $this->db->from('masterusers');
        $users = $this->db->count_all_results();

        $statistics = array(
            "admins" => $admins,
            "masters" => $masters,
            "supervisors" => $supervisors,
            "users" => $users
        );

        return $statistics;
    }

    public function sendPassword() {
        $this->db->select('*');
        $this->db->from("masterusers");
        $this->db->where('email', $this->input->post('email'));
        $query = $this->db->get();
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($query->num_rows() > 0) {
            $get_name = $query->row_array();
            $data = array(
                'password' => md5($get_name['id'])
            );
            $this->db->where('id', $get_name['id']);
            $this->db->update('masterusers', $data);
            $this->load->library('email');
            $this->email->from('support@cisinlabs.com', 'Jaswant Singh Jatav');
            $this->email->to($this->input->post('email'));
            $this->email->subject('Forgot password response');
            $this->email->message("<div style='padding:5px 10px ; border:1px dashed #fff; background:#39F; font:12px Arial, Helvetica, sans-serif; color:#fff;'>
            <p><strong>Dear Applicant,</strong></p>
            <table>
            <tr>            
            <td>
             New-password: '" . md5($get_name['id']) . "'
            </td>
            </tr>
            </table>
            <p><strong>Admin,Wegotticket.com</strong></p>
            </div>");
            $query = $this->email->send();
            return $query;
        } else {

            return $query->row_array();
        }
    }

    public function setRememberMe() {
        if ($this->input->post('rememberme')) {
            setcookie("username", $this->input->post('username'));
            setcookie("password", $this->input->post('password'));
        } else {
            if (isset($_COOKIE['password'])) {
                setcookie("username", "");
                setcookie("password", "");
            }
        }
    }

    public function setLastLogin() {
        $data = array(
            'last_login' => date('d-m-Y h:i:s a')
        );
        $this->db->where('id', $this->session->userdata("admin_id"));
        $this->db->update('masterusers', $data);
    }

    ///Users Actions

    public function viewUser() {

        log_message('info', 'Model_users logged_in method called successfully');
        $this->db->select('*');
        $this->db->from("masterusers");
        $this->db->where('id', $this->input->post('id'));
        $this->db->where('user_type', 4);
        $query = $this->db->get();
        $result = array();
        $result['success'] = "";
        $result['error'] = "";

        if ($query->num_rows() > 0) {
            $result['record'] = $query->row_array();
            $result['success'] = 1;
        } else {
            $result['error'] = "Sorry no such user found in database";
        }

        return json_encode($result);
    }

    public function delUsers() {
        $result = array();
        $result['success'] = "";
        $result['error'] = "";

        $data = array(
            'is_deleted' => 1
        );
        $this->db->where_in('id', $this->input->post('ids'));
        $this->db->where('user_type', 4);
        $foo = $this->db->update('masterusers', $data);
        if ($foo) {
            $result['success'] = $foo;
        } else {
            $result['error'] = "Sorry but record can't deleted !";
        }
        return json_encode($result);
    }

    public function editUser() {
        $data = array(
            'first_name' => $this->input->post('firstname'),
            'last_name' => $this->input->post('lastname'),
            'mobile' => $this->input->post('mobile'),
            'email' => $this->input->post('email'),
            'address' => $this->input->post('address')
        );
        $this->db->where('id', $this->input->post('id'));
        $this->db->where('user_type', 4);
        $foo = $this->db->update('masterusers', $data);
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($foo) {
            $result['success'] = $foo;
        } else {
            $result['error'] = "Sorry ! user can't update successfully";
        }
        return json_encode($result);
    }

    public function addUser() {
        $data = array(
            'first_name' => $this->input->post('firstname'),
            'last_name' => $this->input->post('lastname'),
            'mobile' => $this->input->post('mobile'),
            'email' => $this->input->post('email'),
            'address' => $this->input->post('address'),
            'user_type' => 4
        );

        $foo = $this->db->insert('masterusers', $data);
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($foo) {
            $result['success'] = $this->db->insert_id();
        } else {
            $result['error'] = "Sorry ! user can't added successfully";
        }
        return json_encode($result);
    }

    ///End of Users actions
    ///Supervisors Actions

    public function viewSupervisor() {

        log_message('info', 'Model_users logged_in method called successfully');
        $this->db->select('*');
        $this->db->from("masterusers");
        $this->db->where('id', $this->input->post('id'));
        $this->db->where('user_type', 3);
        $query = $this->db->get();
        $result = array();
        $result['success'] = "";
        $result['error'] = "";

        if ($query->num_rows() > 0) {
            $result['record'] = $query->row_array();
            $result['success'] = 1;
        } else {
            $result['error'] = "Sorry no such user found in database";
        }

        return json_encode($result);
    }

    public function delSupervisors() {
        $result = array();
        $result['success'] = "";
        $result['error'] = "";

        $data = array(
            'is_deleted' => 1
        );
        $this->db->where_in('id', $this->input->post('ids'));
        $this->db->where('user_type', 3);
        $foo = $this->db->update('masterusers', $data);
        if ($foo) {
            $result['success'] = $foo;
        } else {
            $result['error'] = "Sorry but record can't deleted !";
        }
        return json_encode($result);
    }

    public function editSupervisor() {
        $data = array(
            'first_name' => $this->input->post('firstname'),
            'last_name' => $this->input->post('lastname'),
            'mobile' => $this->input->post('mobile'),
            'email' => $this->input->post('email'),
            'address' => $this->input->post('address')
        );
        $this->db->where('id', $this->input->post('id'));
        $this->db->where('user_type', 3);
        $foo = $this->db->update('masterusers', $data);
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($foo) {
            $result['success'] = $foo;
        } else {
            $result['error'] = "Sorry ! user can't update successfully";
        }
        return json_encode($result);
    }

    public function addSupervisor() {
        $data = array(
            'first_name' => $this->input->post('firstname'),
            'last_name' => $this->input->post('lastname'),
            'mobile' => $this->input->post('mobile'),
            'email' => $this->input->post('email'),
            'address' => $this->input->post('address'),
            'user_type' => 3
        );

        $foo = $this->db->insert('masterusers', $data);
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($foo) {
            $result['success'] = $this->db->insert_id();
        } else {
            $result['error'] = "Sorry ! user can't added successfully";
        }
        return json_encode($result);
    }

    ///End of Supervisors actions
    ///Masters Actions

    public function viewMaster() {

        log_message('info', 'Model_users logged_in method called successfully');
        $this->db->select('*');
        $this->db->from("masterusers");
        $this->db->where('id', $this->input->post('id'));
        $this->db->where('user_type', 2);
        $query = $this->db->get();
        $result = array();
        $result['success'] = "";
        $result['error'] = "";

        if ($query->num_rows() > 0) {
            $result['record'] = $query->row_array();
            $result['success'] = 1;
        } else {
            $result['error'] = "Sorry no such user found in database";
        }

        return json_encode($result);
    }

    public function delMasters() {
        $result = array();
        $result['success'] = "";
        $result['error'] = "";

        $data = array(
            'is_deleted' => 1
        );
        $this->db->where_in('id', $this->input->post('ids'));
        $this->db->where('user_type', 2);
        $foo = $this->db->update('masterusers', $data);
        if ($foo) {
            $result['success'] = $foo;
        } else {
            $result['error'] = "Sorry but record can't deleted !";
        }
        return json_encode($result);
    }

    public function editMaster() {
        $data = array(
            'first_name' => $this->input->post('firstname'),
            'last_name' => $this->input->post('lastname'),
            'mobile' => $this->input->post('mobile'),
            'email' => $this->input->post('email'),
            'address' => $this->input->post('address')
        );
        $this->db->where('id', $this->input->post('id'));
        $this->db->where('user_type', 2);
        $foo = $this->db->update('masterusers', $data);
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($foo) {
            $result['success'] = $foo;
        } else {
            $result['error'] = "Sorry ! user can't update successfully";
        }
        return json_encode($result);
    }

    public function addMaster() {
        $data = array(
            'first_name' => $this->input->post('firstname'),
            'last_name' => $this->input->post('lastname'),
            'mobile' => $this->input->post('mobile'),
            'email' => $this->input->post('email'),
            'address' => $this->input->post('address'),
            'user_type' => 2
        );

        $foo = $this->db->insert('masterusers', $data);
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($foo) {
            $result['success'] = $this->db->insert_id();
        } else {
            $result['error'] = "Sorry ! user can't added successfully";
        }
        return json_encode($result);
    }

    ///End of Masters actions
    ///Admin Actions

    public function viewAdmin() {

        log_message('info', 'Model_users logged_in method called successfully');
        $this->db->select('*');
        $this->db->from("masterusers");
        $this->db->where('id', $this->input->post('id'));
        $this->db->where('user_type', 1);
        $query = $this->db->get();
        $result = array();
        $result['success'] = "";
        $result['error'] = "";

        if ($query->num_rows() > 0) {
            $result['record'] = $query->row_array();
            $result['success'] = 1;
        } else {
            $result['error'] = "Sorry no such user found in database";
        }

        return json_encode($result);
    }

    public function delAdmins() {
        $result = array();
        $result['success'] = "";
        $result['error'] = "";

        $data = array(
            'is_deleted' => 1
        );
        $this->db->where_in('id', $this->input->post('ids'));
        $foo = $this->db->update('masterusers', $data);
        if ($foo) {
            $result['success'] = $foo;
        } else {
            $result['error'] = "Sorry but record can't deleted !";
        }
        return json_encode($result);
    }

    public function editAdmin() {
        $data = array(
            'first_name' => $this->input->post('firstname'),
            'last_name' => $this->input->post('lastname'),
            'mobile' => $this->input->post('mobile'),
            'email' => $this->input->post('email'),
            'address' => $this->input->post('address')
        );
        $this->db->where('id', $this->input->post('id'));
        $foo = $this->db->update('masterusers', $data);
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($foo) {
            $result['success'] = $foo;
        } else {
            $result['error'] = "Sorry ! user can't update successfully";
        }
        return json_encode($result);
    }

    public function addAdmin() {
        $data = array(
            'first_name' => $this->input->post('firstname'),
            'last_name' => $this->input->post('lastname'),
            'mobile' => $this->input->post('mobile'),
            'email' => $this->input->post('email'),
            'address' => $this->input->post('address'),
            'user_type' => 1
        );

        $foo = $this->db->insert('masterusers', $data);
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($foo) {
            $result['success'] = $this->db->insert_id();
        } else {
            $result['error'] = "Sorry ! user can't added successfully";
        }
        return json_encode($result);
    }

    ///End of Admins actions

    public function getSupervisors() {

        log_message('info', 'Model_users logged_in method called successfully');
        $this->db->select('*');
        $this->db->from("masterusers");
        $this->db->where('user_type', 3);
        $this->db->where('is_deleted', 0);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }

    public function getMasters() {

        log_message('info', 'Model_users logged_in method called successfully');
        $this->db->select('*');
        $this->db->from("masterusers");
        $this->db->where('user_type', 2);
        $this->db->where('is_deleted', 0);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }

    public function getUsers() {

        log_message('info', 'Model_users logged_in method called successfully');
        $this->db->select('*');
        $this->db->from("masterusers");
        $this->db->where('user_type', 4);
        $this->db->where('is_deleted', 0);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }

    public function getAdmins() {

        log_message('info', 'Model_users logged_in method called successfully');
        $this->db->select('*');
        $this->db->from("masterusers");
        $this->db->where('user_type', 1);
        $this->db->where('is_deleted', 0);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }

    public function getAdminprofile() {
        log_message('info', 'Model_users logged_in method called suuessfully');
        $this->db->select('*');
        $this->db->from('masterusers');
        $this->db->where('id', $this->session->userdata("admin_id"));
        $this->db->where('is_deleted', 0);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }

    public function editProfile() {

        $data = array(
            'first_name' => $this->input->post('firstname'),
            'last_name' => $this->input->post('lastname'),
            'mobile' => $this->input->post('mobile'),
            'email' => $this->input->post('email'),
            'address' => $this->input->post('address')
        );
        if ($this->input->post('password') != '')
            $data['password'] = md5($this->input->post('password'));
        $this->db->where('id', $this->session->userdata("admin_id"));
        $foo = $this->db->update('masterusers', $data);
        //echo $this->db->last_query();die;
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($foo) {
            $result['success'] = $foo;
        } else {
            $result['error'] = "Sorry ! user can't update successfully";
        }
        return $result;
    }

}

/*
  .::File Details::.
  End of file model_admin.php
  Created By : mayank awasthi
  Firm Name : Cyber Infrastructure Pvt. Ltd. India < http://cisin.com >
  Location: ./application/Models/model_admin.php
  Created At : 16 Nov, 2013  5:22:12 PM
 */
?>
