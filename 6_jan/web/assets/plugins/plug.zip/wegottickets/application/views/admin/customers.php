<?php

//put your code here
















/*
  .::File Details::.
  End of file customers.php
  Project Name: wegottickets
  Created By : Jaswant Singh
  Firm Name : Cyber Infrastructure Pvt. Ltd. India < http://cisin.com >
  File Location: ./application/views/customers.php
  Created At : 15 Nov, 2013  7:47:30 PM
 */
?>
