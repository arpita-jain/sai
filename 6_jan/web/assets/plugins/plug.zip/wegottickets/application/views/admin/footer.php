<!-- Bootstrap core JavaScript -->
<script src="<?php echo base_url(); ?>assets/admin/js/bootstrap.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/bootbox.js"></script>
<!-- Page Specific Plugins -->
<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/morris/chart-data-morris.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/data-tables/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/data-tables/TableTools/media/js/ZeroClipboard.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/data-tables/TableTools/media/js/TableTools.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/data-tables/DT_bootstrap.js"></script>
</body>
</html>

<?php
/*
  .::File Details::.
  End of file footer.php
  Created By : Jaswant Singh
  Firm Name : Cyber Infrastructure Pvt. Ltd. India < http://cisin.com >
  Location: ./application/Controllers/footer.php
  Created At : 15 Nov, 2013  2:41:19 PM
 */
?>
