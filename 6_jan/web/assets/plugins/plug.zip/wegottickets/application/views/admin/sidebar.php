

<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.html"><i class="icon-tags"></i> WeGotTickets</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav side-nav">
            <li id="dashboard_menu"><a href="<?php echo site_url(); ?>admin/"><i class="icon-dashboard"></i> Dashboard</a></li>
            <?php if ($this->session->userdata("admin_type") == 0) { ?>
                <li id="admins_menu"><a  href="<?php echo site_url(); ?>admin/administrators"><i class="icon-group"></i> Administrators</a></li>
                <li id="masters_menu"><a href="<?php echo site_url(); ?>admin/masters"><i class="icon-group"></i> Master users</a></li>
                <li id="supervisors_menu"><a href="<?php echo site_url(); ?>admin/supervisors"><i class="icon-group"></i> Supervisor users</a></li>
                <li id="users_menu"><a href="<?php echo site_url(); ?>admin/users"><i class="icon-group"></i> Users</a></li>
            <?php } ?>

            <?php if ($this->session->userdata("admin_type") == 1) { ?>                
                <li id="masters_menu"><a href="<?php echo site_url(); ?>admin/masters"><i class="icon-group"></i> Master users</a></li>
                <li id="supervisors_menu"><a href="<?php echo site_url(); ?>admin/supervisors"><i class="icon-group"></i> Supervisor users</a></li>
                <li id="users_menu"><a href="<?php echo site_url(); ?>admin/users"><i class="icon-group"></i> Users</a></li>
            <?php } ?>

            <?php if ($this->session->userdata("admin_type") == 2) { ?>
                <li id="supervisors_menu"><a href="<?php echo site_url(); ?>admin/supervisors"><i class="icon-group"></i> Supervisor users</a></li>
                <li id="users_menu"><a href="<?php echo site_url(); ?>admin/users"><i class="icon-group"></i> Users</a></li>
            <?php } ?>

            <?php if ($this->session->userdata("admin_type") == 3) { ?>
                <li id="users_menu"><a href="<?php echo site_url(); ?>admin/users"><i class="icon-group"></i> Users</a></li>
            <?php } ?>
        </ul>

        <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-user"></i> <?php echo $this->session->userdata('admin_email'); ?> <b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo site_url(); ?>admin/adminprofile"><i class="icon-user"></i> Profile</a></li>
<!--                    <li><a href="#"><i class="icon-gear"></i> Settings</a></li>-->
                    <li class="divider"></li>
                    <li><a href="<?php echo site_url(); ?>admin/logout"><i class="icon-power-off"></i> Log Out</a></li>
                </ul>
            </li>
        </ul>
    </div><!-- /.navbar-collapse -->
</nav>

<?php
/*
  .::File Details::.
  End of file sidebar.php
  Project Name: wegottickets
  Created By : Jaswant Singh
  Firm Name : Cyber Infrastructure Pvt. Ltd. India < http://cisin.com >
  File Location: ./application/views/sidebar.php
  Created At : 15 Nov, 2013  2:46:59 PM
 */
?>
