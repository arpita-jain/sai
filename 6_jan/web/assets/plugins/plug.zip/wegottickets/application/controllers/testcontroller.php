<?php

/*
 * Class Description
 * Project Name: wegottickets
 * Class name : testcontroller
 * File name testcontroller.php
 */

class testcontroller {
//put your code here
}

/*
  .::File Details::.
  End of file testcontroller.php
  Created By : Jaswant Singh
  Firm Name : Cyber Infrastructure Pvt. Ltd. India < http://cisin.com >
  Location: ./application/Controllers/testcontroller.php
  Created At : 15 Nov, 2013  7:48:00 PM
 */
?>
