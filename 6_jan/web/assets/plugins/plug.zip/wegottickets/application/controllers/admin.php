<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/*
 * Class Description
 * Project Name: wegottickets
 * Class name : admins
 * File name admins.php
 */

class Admin extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->model('Model_admin');
        $this->isLoggedIn();
    }

    public function testKiosk() {
        $this->load->add_package_path(APPPATH . 'third_party/Kiosk_Library/src/InternetTickets/WeGotTickets/Api/v1/Client/Kiosk', TRUE);
        $this->load->library('Kiosk');
        $data = $this->Kiosk->fetchAllData();
        print_r($data);
    }

    public function isLoggedIn() {
        if ($this->session->userdata('admin_logged_in') != TRUE) {
            redirect("auth");
        }
    }

    public function index() {
        $data['users'] = $this->Model_admin->getStatistics();
        $this->load->view('admin/header');
        $this->load->view('admin/dashboard', $data);
        $this->load->view('admin/footer');
    }

    public function administrators() {
        if ($this->session->userdata("admin_type") > 0) {
            redirect("admin");
        }
        $data['admins'] = $this->Model_admin->getAdmins();
        $this->load->view('admin/header');
        $this->load->view('admin/admins', $data);
        $this->load->view('admin/footer');
    }

    public function supervisors() {
        if ($this->session->userdata("admin_type") > 2) {
            redirect("admin");
        }
        $data['admins'] = $this->Model_admin->getSupervisors();
        $this->load->view('admin/header');
        $this->load->view('admin/supervisors', $data);
        $this->load->view('admin/footer');
    }

    public function masters() {
        if ($this->session->userdata("admin_type") > 1) {
            redirect("admin");
        }
        $data['admins'] = $this->Model_admin->getMasters();
        $this->load->view('admin/header');
        $this->load->view('admin/masters', $data);
        $this->load->view('admin/footer');
    }

    public function users() {
        if ($this->session->userdata("admin_type") > 3) {
            redirect("admin");
        }
        $data['admins'] = $this->Model_admin->getUsers();
        $this->load->view('admin/header');
        $this->load->view('admin/users', $data);
        $this->load->view('admin/footer');
    }

    public function adminprofile() {
       
        $data['profile'] = $this->Model_admin->getAdminprofile();
        $this->load->view('admin/header');
        $this->load->view('admin/profile', $data);
        $this->load->view('admin/footer');
    }

    public function logout() {

        $this->session->sess_destroy();
        redirect("auth");
    }

}

/*
  .::File Details::.
  End of file admins.php
  Created By : Jaswant Singh
  Firm Name : Cyber Infrastructure Pvt. Ltd. India < http://cisin.com >
  Location: ./application/Controllers/admins.php
  Created At : 15 Nov, 2013  1:45:20 PM
 */
?>
