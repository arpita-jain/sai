<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/*
 * Class Description
 * Project Name: wegottickets
 * Class name : admin_ajax
 * File name admin_ajax.php
 */

class Admin_ajax extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->model('Model_admin');
        $this->isLoggedIn();
    }

    public function isLoggedIn() {
        if ($this->session->userdata('admin_logged_in') != TRUE) {
            redirect("auth");
        }
    }

    ///Admin Actions
    public function delAdmins() {
        echo $this->Model_admin->delAdmins();
    }

    public function viewAdmin() {
        echo $this->Model_admin->viewAdmin();
    }

    public function addAdmin() {
        $this->form_validation->set_rules('firstname', 'First name', 'required');
        $this->form_validation->set_rules('lastname', 'Last name', 'required');
        $this->form_validation->set_rules('email', 'Email address', 'required|valid_email');
        $this->form_validation->set_rules('mobile', 'Mobile', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($this->form_validation->run() === TRUE) {
            echo $this->Model_admin->addAdmin();
        } else {
            $result['error'] = validation_errors();
        }
        echo json_encode($result);
    }

    

    public function editAdmin() {
        $this->form_validation->set_rules('firstname', 'First name', 'required');
        $this->form_validation->set_rules('lastname', 'Last name', 'required');
        $this->form_validation->set_rules('email', 'Email address', 'required|valid_email');
        $this->form_validation->set_rules('mobile', 'Mobile', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('id', 'ID', 'required');
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($this->form_validation->run() === TRUE) {
            echo $this->Model_admin->editAdmin();
        } else {
            $result['error'] = validation_errors();
        }
        echo json_encode($result);
    }

    //End of Admin actions
    ///Master Actions
    public function delMasters() {
        echo $this->Model_admin->delMasters();
    }

    public function viewMaster() {
        echo $this->Model_admin->viewMaster();
    }

    public function addMaster() {
        $this->form_validation->set_rules('firstname', 'First name', 'required');
        $this->form_validation->set_rules('lastname', 'Last name', 'required');
        $this->form_validation->set_rules('email', 'Email address', 'required|valid_email');
        $this->form_validation->set_rules('mobile', 'Mobile', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($this->form_validation->run() === TRUE) {
            echo $this->Model_admin->addMaster();
        } else {
            $result['error'] = validation_errors();
        }
        echo json_encode($result);
    }

    public function editMaster() {
        $this->form_validation->set_rules('firstname', 'First name', 'required');
        $this->form_validation->set_rules('lastname', 'Last name', 'required');
        $this->form_validation->set_rules('email', 'Email address', 'required|valid_email');
        $this->form_validation->set_rules('mobile', 'Mobile', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('id', 'ID', 'required');
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($this->form_validation->run() === TRUE) {
            echo $this->Model_admin->editMaster();
        } else {
            $result['error'] = validation_errors();
        }
        echo json_encode($result);
    }

    //End of Master actions
    ///Supervisors Actions
    public function delSupervisors() {
        echo $this->Model_admin->delSupervisors();
    }

    public function viewSupervisor() {
        echo $this->Model_admin->viewSupervisor();
    }

    public function addSupervisor() {
        $this->form_validation->set_rules('firstname', 'First name', 'required');
        $this->form_validation->set_rules('lastname', 'Last name', 'required');
        $this->form_validation->set_rules('email', 'Email address', 'required|valid_email');
        $this->form_validation->set_rules('mobile', 'Mobile', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($this->form_validation->run() === TRUE) {
            echo $this->Model_admin->addSupervisor();
        } else {
            $result['error'] = validation_errors();
        }
        echo json_encode($result);
    }

    public function editSupervisor() {
        $this->form_validation->set_rules('firstname', 'First name', 'required');
        $this->form_validation->set_rules('lastname', 'Last name', 'required');
        $this->form_validation->set_rules('email', 'Email address', 'required|valid_email');
        $this->form_validation->set_rules('mobile', 'Mobile', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('id', 'ID', 'required');
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($this->form_validation->run() === TRUE) {
            echo $this->Model_admin->editSupervisor();
        } else {
            $result['error'] = validation_errors();
        }
        echo json_encode($result);
    }

    //End of Supervisors actions
    ///Users Actions
    public function delUsers() {
        echo $this->Model_admin->delUsers();
    }

    public function viewUser() {
        echo $this->Model_admin->viewUser();
    }

    public function addUser() {
        $this->form_validation->set_rules('firstname', 'First name', 'required');
        $this->form_validation->set_rules('lastname', 'Last name', 'required');
        $this->form_validation->set_rules('email', 'Email address', 'required|valid_email');
        $this->form_validation->set_rules('mobile', 'Mobile', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($this->form_validation->run() === TRUE) {
            echo $this->Model_admin->addUser();
        } else {
            $result['error'] = validation_errors();
        }
        echo json_encode($result);
    }

    public function editUser() {
        $this->form_validation->set_rules('firstname', 'First name', 'required');
        $this->form_validation->set_rules('lastname', 'Last name', 'required');
        $this->form_validation->set_rules('email', 'Email address', 'required|valid_email');
        $this->form_validation->set_rules('mobile', 'Mobile', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('id', 'ID', 'required');
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        if ($this->form_validation->run() === TRUE) {
            echo $this->Model_admin->editUser();
        } else {
            $result['error'] = validation_errors();
        }
        echo json_encode($result);
    }

    //End of Users actions
    
    //start admin profile
     public function editprofile() {
        $this->form_validation->set_rules('firstname', 'First name', 'required');
        $this->form_validation->set_rules('lastname', 'Last name', 'required');
        $this->form_validation->set_rules('email', 'Email address', 'required|valid_email');
        $this->form_validation->set_rules('mobile', 'Mobile', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');        
        $result = array();
        $result['success'] = "";
        $result['error'] = "";
        //print_r($_REQUEST);die;
        if ($this->form_validation->run() === TRUE) {
            echo $this->Model_admin->editProfile();
        } else {
            $result['error'] = validation_errors();
        }
        redirect(site_url()."admin/index");
        echo $result;
    }
    
    //end admin profile
    
}

/*
  .::File Details::.
  End of file admin_ajax.php
  Created By : Jaswant Singh
  Firm Name : Cyber Infrastructure Pvt. Ltd. India < http://cisin.com >
  Location: ./application/Controllers/admin_ajax.php
  Created At : 15 Nov, 2013  1:45:20 PM
 */
?>
