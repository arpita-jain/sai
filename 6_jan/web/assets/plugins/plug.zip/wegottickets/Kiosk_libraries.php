<?php
//require 'InternetTickets/WeGotTickets/Api/v1/Client/Kiosk.php';
//
//
//
//$kiosk = new InternetTickets\WeGotTickets\Api\v1\Client\Kiosk;
//
//$data = $kiosk->fetchAllData();
//print_r($data);
?>

<?php
require 'InternetTickets/WeGotTickets/Api/v1/client/Kiosk.php';

//src/InternetTickets/WeGotTickets/Api/v1/client/Kiosk.php

$kiosk = new InternetTickets\WeGotTickets\Api\v1\Client\Kiosk(new InternetTickets\WeGotTickets\Api\v1\Wrapper\Wrapper);

//$data = $kiosk->fetchAllData();
print_r($kiosk);
?>